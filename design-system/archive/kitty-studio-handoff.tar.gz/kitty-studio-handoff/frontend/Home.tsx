import React, { useState, useEffect, useRef } from 'react';
import { useGetStudioConfig, useGetStudioHealth } from '@workspace/api-client-react';
import type { GenerateInputAspectRatio, GenerateInputResolution, GenerateResult } from '@workspace/api-client-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Loader2, Camera, Settings, Layers, Lock, Cpu, Sliders, ChevronDown, ChevronRight } from 'lucide-react';
import { FileUploader } from '@/components/file-uploader';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { useToast } from '@/hooks/use-toast';

function humanizeLabel(key: string) {
  if (!key) return "";
  const words = key.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1));
  return words.join(' ');
}

export default function Home() {
  const { data: config, isLoading: isConfigLoading, error: configError } = useGetStudioConfig();
  const { data: health } = useGetStudioHealth();
  const { toast } = useToast();

  const [anchorFile, setAnchorFile] = useState<File | null>(null);
  const [editFile, setEditFile] = useState<File | null>(null);
  
  const [engine, setEngine] = useState<string>("");
  const [shotPreset, setShotPreset] = useState<string>("");
  const [correction, setCorrection] = useState<string>("none");
  const [modelProfile, setModelProfile] = useState<string>("");
  
  const [customPrompt, setCustomPrompt] = useState<string>("");
  const [aspectRatio, setAspectRatio] = useState<GenerateInputAspectRatio>("3:4");
  const [resolution, setResolution] = useState<GenerateInputResolution>("2K");
  const [numImages, setNumImages] = useState<string>("1");
  const [strength, setStrength] = useState<number>(0.35);

  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState<GenerateResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [elapsedSecs, setElapsedSecs] = useState(0);
  const [constraintsOpen, setConstraintsOpen] = useState(false);
  const [promptOpen, setPromptOpen] = useState(false);
  const resultsRef = useRef<HTMLElement>(null);

  // Estimated generation time — used for the soft progress bar
  const ESTIMATED_SECS = 60;

  useEffect(() => {
    if (config) {
      if (!engine && Object.keys(config.engines).length > 0) setEngine(Object.keys(config.engines)[0]);
      if (!shotPreset && Object.keys(config.shots).length > 0) setShotPreset(Object.keys(config.shots)[0]);
      if (!modelProfile && Object.keys(config.modelProfiles).length > 0) setModelProfile(Object.keys(config.modelProfiles)[0]);
      if (!correction && config.corrections.includes("none")) setCorrection("none");
      else if (!correction && config.corrections.length > 0) setCorrection(config.corrections[0]);
    }
  }, [config, engine, shotPreset, modelProfile, correction]);

  // Elapsed timer — counts up while generating
  useEffect(() => {
    if (!isGenerating) { setElapsedSecs(0); return; }
    setElapsedSecs(0);
    const id = setInterval(() => setElapsedSecs(s => s + 1), 1000);
    return () => clearInterval(id);
  }, [isGenerating]);

  const handleGenerate = async () => {
    if (!anchorFile) {
      toast({ title: "Anchor missing", description: "Please upload an anchor image.", variant: "destructive" });
      return;
    }
    
    setIsGenerating(true);
    setErrorMsg(null);
    setResult(null);

    try {
      const form = new FormData();
      form.append("anchor", anchorFile);
      if (editFile) form.append("editImage", editFile);
      form.append("engine", engine);
      form.append("shotPreset", shotPreset);
      form.append("correction", correction);
      form.append("modelProfile", modelProfile);
      if (customPrompt) form.append("customPrompt", customPrompt);
      form.append("aspectRatio", aspectRatio);
      form.append("resolution", resolution);
      form.append("numImages", numImages);
      form.append("strength", String(strength));
      
      const res = await fetch(`${import.meta.env.BASE_URL}api/studio/generate`, {
        method: "POST",
        body: form,
      });
      const data = await res.json();
      
      if (!res.ok || !data.ok) {
        throw new Error(data.error || "Generation failed");
      }
      
      setResult(data);
      setPromptOpen(true);
      toast({ title: "Generation Complete", description: "Your image has been generated successfully." });
      setTimeout(() => resultsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 100);
    } catch (err: any) {
      setErrorMsg(err.message || "An unexpected error occurred.");
      toast({ title: "Generation Failed", description: err.message, variant: "destructive" });
    } finally {
      setIsGenerating(false);
    }
  };

  if (configError) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-6">
        <div className="bg-destructive/10 text-destructive border border-destructive/20 p-6 rounded-lg max-w-md w-full font-mono text-sm">
          <p className="font-bold mb-2 uppercase">System Error</p>
          <p>Failed to load studio configuration. Check connection.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground pb-20 selection:bg-primary/30">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-md border-b border-border px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-primary/20 flex items-center justify-center border border-primary/50 text-primary">
            <Camera className="w-4 h-4" />
          </div>
          <div>
            <h1 className="font-sans font-bold text-lg leading-none tracking-tight">Kitty Studio</h1>
            <p className="font-mono text-[10px] text-muted-foreground uppercase tracking-widest mt-1">Image Generation Node</p>
          </div>
        </div>
        
        {config ? (
          <Badge variant="outline" className="border-primary text-primary bg-primary/5 px-3 py-1 font-mono text-xs uppercase tracking-wider">
            {config.character.name} <span className="opacity-50 ml-2">v1.2</span>
          </Badge>
        ) : (
          <div className="flex items-center gap-2 text-muted-foreground font-mono text-xs">
            <Loader2 className="w-3 h-3 animate-spin" />
            <span>INIT</span>
          </div>
        )}
      </header>

      {/* FAL key warning banner */}
      {health && !health.falKeyConfigured && (
        <div className="bg-destructive/10 border-b border-destructive/30 px-6 py-3 flex items-center gap-3 font-mono text-xs text-destructive">
          <span className="font-bold uppercase tracking-widest shrink-0">⚠ No API Key</span>
          <span>FAL_KEY is not configured — generation will fail. Add it in Replit Secrets.</span>
        </div>
      )}

      <main className="max-w-5xl mx-auto p-4 md:p-6 lg:p-8 space-y-6 md:space-y-8 animate-in fade-in duration-500">
        {isConfigLoading || !config ? (
          <div className="h-[60vh] flex flex-col items-center justify-center gap-4 text-muted-foreground">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
            <p className="font-mono text-xs uppercase tracking-widest">Loading Telemetry...</p>
          </div>
        ) : (
          <>
            {/* Character Locks — collapsible, collapsed by default */}
            <Collapsible open={constraintsOpen} onOpenChange={setConstraintsOpen}>
              <section className="bg-card border border-border rounded-xl shadow-sm overflow-hidden">
                <CollapsibleTrigger className="w-full flex items-center justify-between p-4 md:p-5 hover:bg-muted/20 transition-colors">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Lock className="w-4 h-4" />
                    <h2 className="font-mono text-xs font-bold uppercase tracking-widest">Active Constraints</h2>
                  </div>
                  <div className="flex items-center gap-3">
                    {/* Always-visible compact lock pills */}
                    <div className="flex gap-1.5">
                      {['Identity','Eyes','Body','Hair','Style'].map(k => (
                        <Badge key={k} variant="secondary" className="font-mono text-[9px] uppercase px-1.5 py-0.5 bg-primary/10 text-primary border-primary/20">
                          {k}
                        </Badge>
                      ))}
                    </div>
                    {constraintsOpen
                      ? <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" />
                      : <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
                    }
                  </div>
                </CollapsibleTrigger>
                <CollapsibleContent>
                  <div className="px-4 pb-4 md:px-5 md:pb-5 border-t border-border/50 space-y-2 pt-3">
                    {[
                      { k: 'Identity', v: config.character.identity_lock },
                      { k: 'Eyes',     v: config.character.eye_rule },
                      { k: 'Body',     v: config.character.body_lock },
                      { k: 'Hair',     v: config.character.hair_lock },
                      { k: 'Style',    v: config.character.style_lock },
                    ].map(lock => (
                      <div key={lock.k} className="grid grid-cols-[64px_1fr] gap-2 text-xs font-mono leading-relaxed">
                        <span className="text-primary uppercase tracking-widest pt-px shrink-0">{lock.k}:</span>
                        <span className="text-muted-foreground break-words whitespace-normal">{lock.v}</span>
                      </div>
                    ))}
                  </div>
                </CollapsibleContent>
              </section>
            </Collapsible>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
              {/* Left Column - Inputs */}
              <div className="md:col-span-7 space-y-6">
                
                {/* File Uploads */}
                <section className="bg-card border border-border rounded-xl p-4 md:p-5 shadow-sm space-y-4">
                  <div className="flex items-center gap-2 text-muted-foreground border-b border-border/50 pb-3">
                    <Layers className="w-4 h-4" />
                    <h2 className="font-mono text-xs font-bold uppercase tracking-widest">Source Material</h2>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                    <FileUploader label="Anchor Image (Required)" file={anchorFile} onFileChange={setAnchorFile} />
                    <FileUploader label="Base/Edit Image (Optional)" file={editFile} onFileChange={setEditFile} />
                  </div>
                </section>

                {/* Shot & Correction */}
                <section className="bg-card border border-border rounded-xl p-4 md:p-5 shadow-sm space-y-4">
                  <div className="flex items-center gap-2 text-muted-foreground border-b border-border/50 pb-3">
                    <Camera className="w-4 h-4" />
                    <h2 className="font-mono text-xs font-bold uppercase tracking-widest">Composition</h2>
                  </div>
                  <div className="space-y-4 pt-2">
                    <div className="space-y-2">
                      <Label className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest">Shot Preset</Label>
                      <Select value={shotPreset} onValueChange={setShotPreset} disabled={isGenerating}>
                        <SelectTrigger className="bg-background border-border/50 font-medium font-sans">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {Object.entries(config.shots).map(([k, v]) => (
                            <SelectItem key={k} value={k}>{v.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest">Correction Directive</Label>
                      <Select value={correction} onValueChange={setCorrection} disabled={isGenerating}>
                        <SelectTrigger className="bg-background border-border/50 font-medium font-sans">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {config.corrections.map(c => (
                            <SelectItem key={c} value={c}>{humanizeLabel(c)}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </section>

                {/* Prompt Override */}
                <section className="bg-card border border-border rounded-xl p-4 md:p-5 shadow-sm space-y-4">
                   <div className="flex items-center justify-between text-muted-foreground border-b border-border/50 pb-3">
                    <div className="flex items-center gap-2">
                      <Settings className="w-4 h-4" />
                      <h2 className="font-mono text-xs font-bold uppercase tracking-widest">Custom Prompt Override</h2>
                    </div>
                    <span className="text-[10px] uppercase font-mono bg-muted px-2 py-0.5 rounded">Optional</span>
                  </div>
                  <div className="pt-2">
                    <Textarea 
                      placeholder="Add specific details to override or append to the preset prompt..." 
                      className="min-h-[100px] resize-y bg-background font-mono text-sm leading-relaxed border-border/50 focus-visible:ring-primary/50"
                      value={customPrompt}
                      onChange={(e) => setCustomPrompt(e.target.value)}
                      disabled={isGenerating}
                    />
                  </div>
                </section>

              </div>

              {/* Right Column - Core Settings */}
              <div className="md:col-span-5 space-y-6">
                
                {/* Engine & Brain */}
                <section className="bg-card border border-border rounded-xl p-4 md:p-5 shadow-sm space-y-4">
                  <div className="flex items-center gap-2 text-muted-foreground border-b border-border/50 pb-3">
                    <Cpu className="w-4 h-4" />
                    <h2 className="font-mono text-xs font-bold uppercase tracking-widest">Processing Core</h2>
                  </div>
                  <div className="space-y-4 pt-2">
                    <div className="space-y-2">
                      <Label className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest">Engine</Label>
                      <Select value={engine} onValueChange={setEngine} disabled={isGenerating}>
                        <SelectTrigger className="bg-background border-border/50 font-mono text-xs">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {Object.entries(config.engines).map(([k, desc]) => (
                            <SelectItem key={k} value={k}>
                              <div className="flex flex-col text-left">
                                <span className="font-mono text-xs">{k}</span>
                                <span className="text-[10px] text-muted-foreground">{desc}</span>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {/* Description shown below the trigger so it never truncates */}
                      {engine && config.engines[engine] && (
                        <p className="text-[10px] font-mono text-muted-foreground leading-relaxed pt-0.5">
                          {config.engines[engine]}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest">Model Profile</Label>
                      <Select value={modelProfile} onValueChange={setModelProfile} disabled={isGenerating}>
                        <SelectTrigger className="bg-background border-border/50 font-mono text-xs h-auto py-3">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {Object.entries(config.modelProfiles).map(([k, p]) => (
                            <SelectItem key={k} value={k}>
                              <div className="flex flex-col text-left">
                                <span className="font-sans font-medium text-sm">{p.label}</span>
                                <span className="text-[10px] text-muted-foreground max-w-[200px] truncate">{p.description}</span>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </section>

                {/* Adv Options */}
                <section className="bg-card border border-border rounded-xl p-4 md:p-5 shadow-sm space-y-4">
                  <div className="flex items-center gap-2 text-muted-foreground border-b border-border/50 pb-3">
                    <Sliders className="w-4 h-4" />
                    <h2 className="font-mono text-xs font-bold uppercase tracking-widest">Parameters</h2>
                  </div>
                  <div className="grid grid-cols-2 gap-4 pt-2">
                    <div className="space-y-2">
                      <Label className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest">Aspect Ratio</Label>
                      <Select value={aspectRatio} onValueChange={(v: any) => setAspectRatio(v)} disabled={isGenerating}>
                        <SelectTrigger className="bg-background border-border/50 font-mono text-xs"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {['4:5', '3:4', '2:3', '1:1', '16:9'].map(r => (
                            <SelectItem key={r} value={r}>{r}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest">Resolution</Label>
                      <Select value={resolution} onValueChange={(v: any) => setResolution(v)} disabled={isGenerating}>
                        <SelectTrigger className="bg-background border-border/50 font-mono text-xs"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {['1K', '2K', '4K'].map(r => (
                            <SelectItem key={r} value={r}>{r}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest">Count</Label>
                      <Select value={numImages} onValueChange={setNumImages} disabled={isGenerating}>
                        <SelectTrigger className="bg-background border-border/50 font-mono text-xs"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {['1', '2', '3', '4'].map(r => (
                            <SelectItem key={r} value={r}>{r} {parseInt(r) > 1 ? 'Images' : 'Image'}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest">Strength</Label>
                      <Select value={strength.toString()} onValueChange={(v) => setStrength(parseFloat(v))} disabled={isGenerating}>
                        <SelectTrigger className="bg-background border-border/50 font-mono text-xs"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {[0.2, 0.35, 0.5, 0.7].map(r => (
                            <SelectItem key={r} value={r.toString()}>{r}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </section>
                
                {/* Generate Button */}
                <div className="pt-2 sticky bottom-4 z-20">
                  {errorMsg && (
                    <div className="mb-4 bg-destructive/10 text-destructive border border-destructive/20 p-3 rounded-lg text-sm font-mono flex flex-col gap-1">
                      <span className="font-bold uppercase text-[10px]">Error</span>
                      <span>{errorMsg}</span>
                    </div>
                  )}

                  <div className="relative overflow-hidden rounded-xl">
                    {/* Soft progress fill — never reaches 100% until done */}
                    {isGenerating && (
                      <div
                        className="absolute inset-0 bg-primary/20 transition-all duration-1000 ease-linear pointer-events-none"
                        style={{ width: `${Math.min((elapsedSecs / ESTIMATED_SECS) * 100, 92)}%` }}
                      />
                    )}
                    <Button 
                      size="lg" 
                      className="relative w-full h-16 text-lg font-bold uppercase tracking-widest shadow-[0_0_20px_rgba(255,107,0,0.2)] hover:shadow-[0_0_30px_rgba(255,107,0,0.4)] transition-all rounded-xl"
                      onClick={handleGenerate}
                      disabled={isGenerating || !anchorFile}
                    >
                      {isGenerating ? (
                        <div className="flex items-center gap-3">
                          <Loader2 className="w-5 h-5 animate-spin" />
                          <span>Generating… {elapsedSecs}s</span>
                        </div>
                      ) : (
                        "Engage Generation"
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            {/* Results Section */}
            {result && (
              <section ref={resultsRef} className="mt-8 pt-8 border-t border-border animate-in fade-in slide-in-from-bottom-8 duration-700">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-2 h-6 bg-primary rounded-sm"></div>
                  <h2 className="font-mono text-lg font-bold uppercase tracking-widest">Output Sequence</h2>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {result.images.map((imgUrl, i) => (
                    <div key={i} className="flex flex-col gap-3 group">
                      <div className="relative rounded-xl overflow-hidden border-2 border-border bg-card">
                        <img src={imgUrl} alt={`Result ${i+1}`} className="w-full h-auto object-cover" />
                        <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                          <a 
                            href={imgUrl} 
                            target="_blank" 
                            rel="noreferrer" 
                            className="bg-primary text-primary-foreground font-mono text-xs font-bold uppercase tracking-wider px-4 py-2 rounded shadow-lg hover:bg-primary/90 transition-colors"
                          >
                            Open High-Res
                          </a>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <Collapsible open={promptOpen} onOpenChange={setPromptOpen} className="border border-border rounded-xl bg-card mt-8 overflow-hidden shadow-sm">
                  <CollapsibleTrigger className="flex items-center justify-between w-full p-4 hover:bg-muted/30 transition-colors">
                    <span className="text-xs font-mono font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                      <Settings className="w-4 h-4" />
                      Prompt Inspector
                    </span>
                    <div className="flex items-center gap-2">
                      {/* Badge signals "data is here" even when collapsed */}
                      <Badge className="font-mono text-[9px] uppercase px-1.5 py-0.5 bg-primary/15 text-primary border-primary/30 border">
                        Ready
                      </Badge>
                      {promptOpen
                        ? <ChevronDown className="w-4 h-4 text-muted-foreground" />
                        : <ChevronRight className="w-4 h-4 text-muted-foreground" />
                      }
                    </div>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="p-4 pt-0 border-t border-border/50">
                    <div className="bg-background border border-border/50 p-4 rounded-lg mt-4 text-xs font-mono text-foreground whitespace-pre-wrap leading-relaxed shadow-inner">
                      {result.finalPrompt}
                    </div>
                    <div className="flex gap-4 mt-4 text-[10px] font-mono text-muted-foreground uppercase tracking-widest">
                      <span>Model: <span className="text-foreground">{result.modelUsed}</span></span>
                      <span>Rewritten: <span className="text-foreground">{result.promptWasRewritten ? 'Yes' : 'No'}</span></span>
                    </div>
                  </CollapsibleContent>
                </Collapsible>
              </section>
            )}
          </>
        )}
      </main>
    </div>
  );
}
