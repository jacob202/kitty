import React, { useRef } from 'react';
import { Upload, X } from 'lucide-react';
import { cn } from '@/lib/utils';

export function FileUploader({ 
  label, 
  file, 
  onFileChange, 
  accept = "image/*" 
}: { 
  label: string; 
  file: File | null; 
  onFileChange: (f: File | null) => void;
  accept?: string;
}) {
  const inputRef = useRef<HTMLInputElement>(null);

  return (
    <div className="flex flex-col gap-2">
      <span className="text-[10px] font-bold text-muted-foreground font-mono uppercase tracking-widest">{label}</span>
      <div 
        className={cn(
          "relative flex items-center justify-center border border-dashed rounded-lg p-4 transition-all duration-200",
          file ? "border-primary/50 bg-primary/5" : "border-border hover:bg-muted/50 hover:border-primary/30",
          "cursor-pointer overflow-hidden min-h-[140px]"
        )}
        onClick={() => !file && inputRef.current?.click()}
      >
        <input 
          type="file" 
          ref={inputRef} 
          className="hidden" 
          accept={accept} 
          onChange={(e) => {
            if (e.target.files?.[0]) onFileChange(e.target.files[0]);
            if (inputRef.current) inputRef.current.value = '';
          }} 
        />
        {file ? (
          <div className="flex flex-col items-center gap-3 w-full animate-in fade-in zoom-in-95">
            <div className="relative w-full flex justify-center">
              <img src={URL.createObjectURL(file)} alt="Preview" className="h-32 w-auto object-cover rounded-md shadow-md border border-border/50" />
              <button 
                onClick={(e) => { e.stopPropagation(); onFileChange(null); }}
                className="absolute top-0 right-0 md:-right-2 md:-top-2 p-1.5 bg-background border border-border hover:bg-destructive hover:text-destructive-foreground rounded-full transition-colors shadow-sm"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <span className="text-xs text-muted-foreground font-mono truncate max-w-[200px]">{file.name}</span>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-2 text-muted-foreground py-6">
            <Upload className="w-6 h-6 mb-1 opacity-50" />
            <span className="text-xs font-mono uppercase tracking-wider opacity-70">Select Image</span>
          </div>
        )}
      </div>
    </div>
  );
}
