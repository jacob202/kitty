# Kitty Image Studio — Handoff Package

Built June 2026. Drop these files into any Express + React project and you're running.

---

## What's in this zip

```
HANDOFF.md                  ← you are here
backend/
  studio-data.ts            ← all character locks, shot presets, corrections, model profiles, prompt builder
  fal-engines.ts            ← fal.ai engine runners (Nano Banana, PuLID, FLUX edit, ComfyUI)
  studio-route.ts           ← Express route handlers: GET /studio/health, GET /studio/config, POST /studio/generate
frontend/
  Home.tsx                  ← full React control panel UI (the whole page)
  FileUploader.tsx          ← drag-and-drop image upload component
```

---

## Backend integration

### 1. Install dependencies

```bash
npm install @fal-ai/client multer undici
npm install -D @types/multer
```

### 2. Add the route to your Express app

```ts
// app.ts or server.ts
import studioRouter from "./routes/studio-route";
app.use("/api/studio", studioRouter);
```

The route uses `multer` for multipart file uploads.  
Add this **after** your normal routes to catch upload errors and clean temp files:

```ts
import fs from "node:fs/promises";

app.use(async (err, req, res, _next) => {
  const filesMap = req.files as Record<string, Express.Multer.File[]> | Express.Multer.File[] | undefined;
  const allFiles = Array.isArray(filesMap) ? filesMap : Object.values(filesMap ?? {}).flat();
  await Promise.all(allFiles.map(f => fs.unlink(f.path).catch(() => {})));
  const isMulterError = err instanceof Error && err.constructor.name === "MulterError";
  res.status(isMulterError ? 400 : 500).json({ ok: false, error: err?.message ?? "Upload failed." });
});
```

### 3. Create an uploads directory

```bash
mkdir -p uploads
```

Multer writes temp files there. Add it to `.gitignore`.

### 4. Set environment variables

| Variable | Required | Description |
|---|---|---|
| `FAL_KEY` | ✅ Yes | fal.ai API key — get one at https://fal.ai |
| `MISTRAL_API_KEY` + `MISTRAL_MODEL` | Optional | Mistral prompt rewriting |
| `OPENROUTER_API_KEY` + `OPENROUTER_MODEL` | Optional | OpenRouter as Mistral fallback |
| `OLLAMA_BASE_URL` + `OLLAMA_MODEL` | Optional | Local Ollama prompt rewriting |
| `COMFY_URL` + `COMFY_CHECKPOINT` | Optional | Remote ComfyUI (RunPod / Colab) |

### 5. fal.ai key config

`fal-engines.ts` calls `fal.config({ credentials: process.env.FAL_KEY })` at startup.  
Call `configureFal()` once when your server boots:

```ts
import { configureFal } from "./fal-engines";
configureFal();
```

---

## Frontend integration

### 1. Install dependencies

```bash
npm install lucide-react
# plus shadcn/ui components if not already installed:
# Button, Badge, Label, Select, Textarea, Collapsible, Toaster
# https://ui.shadcn.com/docs/installation
```

### 2. Copy files

- `Home.tsx` → your pages directory  
- `FileUploader.tsx` → your components directory

### 3. Fix the API base URL

`Home.tsx` posts to:

```ts
`${import.meta.env.BASE_URL}api/studio/generate`
```

If your Vite app is at root (`/`), this resolves to `/api/studio/generate`.  
If your backend is on a separate port, replace with your full backend URL.

### 4. shadcn/ui components used

The page imports from `@/components/ui/`:

```
select, button, badge, label, textarea, collapsible
```

And from `@/hooks/`:

```
use-toast
```

Install or copy them from https://ui.shadcn.com if you don't have them already.

---

## API contract

### GET /api/studio/health
Returns `{ falKeyConfigured: boolean }`.  
Use to show a warning banner if the key is missing.

### GET /api/studio/config
Returns all character locks, engine list, shot presets, corrections, and model profiles.  
The frontend loads this on boot and locks controls until it arrives.

### POST /api/studio/generate
`multipart/form-data` — required fields:

| Field | Type | Notes |
|---|---|---|
| `anchor` | File | Face reference image (required) |
| `editImage` | File | Base image for FLUX edit engine (optional) |
| `engine` | string | `fal_nano_banana_edit` / `fal_pulid` / `fal_flux_edit` / `comfy_remote_basic` |
| `shotPreset` | string | Key from config.shots |
| `correction` | string | Key from config.corrections |
| `modelProfile` | string | Key from config.modelProfiles |
| `customPrompt` | string | Appended to preset prompt (optional) |
| `aspectRatio` | string | `4:5` / `3:4` / `2:3` / `1:1` / `16:9` |
| `resolution` | string | `1K` / `2K` / `4K` |
| `numImages` | string | `1`–`4` |
| `strength` | string | `0.1`–`0.9` |

Response: `{ ok: true, images: string[], finalPrompt: string, modelUsed: string, promptWasRewritten: boolean }`

---

## Customising the character locks

Everything about Jacob Bear lives in `studio-data.ts`:

- `CHARACTER` — identity, eye, body, hair, and style lock strings
- `SHOT_PRESETS` — named shot setups with prompt fragments
- `CORRECTIONS` — corrective directives appended to the prompt
- `MODEL_PROFILES` — prompt rewriting strategies (Rules Only, Mistral, etc.)
- `buildPrompt()` — assembles the final prompt from all the above

Change any of those objects and the change propagates everywhere — no other files need touching.

---

## Notes & gotchas

- **`fal-ai/flux-pulid` does not support `num_images`** — the fal SDK type doesn't include it. Batch size is dropped for that engine; it always returns 1 image.
- **fal SDK strict enums** — `aspect_ratio` and `resolution` use string literal union types in the SDK. The route validates inputs against an allowed list; the engine calls cast to `any` to avoid TypeScript errors.
- **Multer temp files** — always cleaned up in the route handler on both success and error paths. The app-level error middleware cleans them if multer itself fails.
- **Mistral / OpenRouter / Ollama** — all optional. If none are configured, the `rules_only` model profile is used (no LLM rewrite, just the raw assembled prompt). Everything still works.
