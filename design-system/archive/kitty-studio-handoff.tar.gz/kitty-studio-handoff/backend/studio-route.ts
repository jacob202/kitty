import { Router, type IRouter } from "express";
import multer from "multer";
import {
  CHARACTER,
  SHOT_PRESETS,
  CORRECTIONS,
  MODEL_PROFILES,
  buildSystemPrompt,
  buildRawPrompt,
  maybeRewritePromptWithModel,
} from "../lib/studio-data.js";
import {
  configureFal,
  uploadFileToFal,
  cleanupFiles,
  runFalNanoBananaEdit,
  runFalPuLID,
  runFalFluxEdit,
  runComfyRemoteBasic,
} from "../lib/fal-engines.js";

configureFal();

const upload = multer({ dest: "uploads/" });
const router: IRouter = Router();

router.get("/health", (_req, res) => {
  res.json({ falKeyConfigured: !!(process.env.FAL_KEY || process.env.FAL_API_KEY) });
});

router.get("/config", (_req, res) => {
  res.json({
    character: CHARACTER,
    shots: SHOT_PRESETS,
    corrections: Object.keys(CORRECTIONS),
    modelProfiles: Object.fromEntries(
      Object.entries(MODEL_PROFILES).map(([key, value]) => [
        key,
        { label: value.label, description: value.description ?? value.provider },
      ])
    ),
    engines: {
      fal_nano_banana_edit: "fal.ai Nano Banana 2 Edit — best default for reference-image editing",
      fal_pulid: "fal.ai PuLID — face-lock generation from one reference",
      fal_flux_edit: "fal.ai FLUX edit — edit an existing generated image",
      comfy_remote_basic: "Remote ComfyUI basic SDXL workflow — RunPod/Colab/local",
    },
  });
});

router.post(
  "/generate",
  upload.fields([
    { name: "anchor", maxCount: 1 },
    { name: "editImage", maxCount: 1 },
  ]),
  async (req, res) => {
    const filesMap = req.files as Record<string, Express.Multer.File[]> | undefined;
    const anchorFile = filesMap?.anchor?.[0];
    const editFile = filesMap?.editImage?.[0];
    const allFiles = [...(filesMap?.anchor ?? []), ...(filesMap?.editImage ?? [])];

    try {
      const VALID_ENGINES = ["fal_nano_banana_edit", "fal_pulid", "fal_flux_edit", "comfy_remote_basic"] as const;
      const VALID_ASPECT_RATIOS = ["4:5", "3:4", "2:3", "1:1", "16:9"] as const;
      const VALID_RESOLUTIONS = ["1K", "2K", "4K"] as const;

      const engine = VALID_ENGINES.includes(req.body.engine) ? (req.body.engine as string) : "fal_nano_banana_edit";
      const shotPreset = (req.body.shotPreset as string) || "close_swimwear";
      const correction = (req.body.correction as string) || "none";
      const modelProfile = (req.body.modelProfile as string) || "rules_only";
      const customPrompt = (req.body.customPrompt as string) || "";
      const aspectRatio = VALID_ASPECT_RATIOS.includes(req.body.aspectRatio) ? (req.body.aspectRatio as string) : "4:5";
      const resolution = VALID_RESOLUTIONS.includes(req.body.resolution) ? (req.body.resolution as string) : "1K";
      const rawNumImages = Number(req.body.numImages);
      const numImages = Number.isFinite(rawNumImages) ? Math.max(1, Math.min(Math.floor(rawNumImages), 4)) : 1;
      const rawStrength = Number(req.body.strength);
      const strength = Number.isFinite(rawStrength) ? Math.max(0.1, Math.min(rawStrength, 0.9)) : 0.35;

      if (!anchorFile && engine !== "comfy_remote_basic") {
        await cleanupFiles(allFiles);
        res.status(400).json({ ok: false, error: "Upload a face anchor image first." });
        return;
      }
      if (engine === "fal_flux_edit" && !editFile) {
        await cleanupFiles(allFiles);
        res.status(400).json({ ok: false, error: "fal FLUX edit needs an edit/base image." });
        return;
      }

      const systemPrompt = buildSystemPrompt();
      const rawPrompt = buildRawPrompt({ shotPreset, correction, customPrompt });
      const rewritten = await maybeRewritePromptWithModel({
        rawPrompt,
        systemPrompt,
        modelProfile,
      });
      const finalPrompt = rewritten.prompt;

      let anchorUrl: string | undefined;
      let editUrl: string | undefined;
      if (anchorFile) anchorUrl = await uploadFileToFal(anchorFile);
      if (editFile) editUrl = await uploadFileToFal(editFile);

      let images: string[] = [];

      if (engine === "fal_nano_banana_edit") {
        images = await runFalNanoBananaEdit({
          anchorUrl: anchorUrl!,
          editUrl,
          systemPrompt,
          prompt: finalPrompt,
          numImages,
          aspectRatio,
          resolution,
        });
      } else if (engine === "fal_pulid") {
        images = await runFalPuLID({
          anchorUrl: anchorUrl!,
          systemPrompt,
          prompt: finalPrompt,
          numImages,
        });
      } else if (engine === "fal_flux_edit") {
        images = await runFalFluxEdit({
          editUrl: editUrl!,
          systemPrompt,
          prompt: finalPrompt,
          numImages,
          strength,
        });
      } else if (engine === "comfy_remote_basic") {
        images = await runComfyRemoteBasic({
          prompt: `${systemPrompt}\n${finalPrompt}`,
          aspectRatio,
        });
      } else {
        throw new Error(`Unknown engine: ${engine}`);
      }

      await cleanupFiles(allFiles);

      res.json({
        ok: true,
        engine,
        shotPreset,
        correction,
        modelProfile,
        modelUsed: rewritten.modelLabel,
        promptWasRewritten: rewritten.usedModel,
        systemPrompt,
        finalPrompt,
        images,
      });
    } catch (err) {
      await cleanupFiles(allFiles);
      req.log.error({ err }, "Generation failed");
      res.status(500).json({
        ok: false,
        error: err instanceof Error ? err.message : "Generation failed.",
      });
    }
  }
);

export default router;
