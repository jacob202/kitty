import { fal } from "@fal-ai/client";
import { Blob } from "node:buffer";
import fs from "node:fs/promises";
import { File } from "undici";

export function configureFal(): void {
  fal.config({
    credentials: process.env.FAL_KEY ?? process.env.FAL_API_KEY ?? "",
  });
}

export async function uploadFileToFal(file: Express.Multer.File): Promise<string> {
  const data = await fs.readFile(file.path);
  const mime = file.mimetype ?? "image/png";
  const blob = new Blob([data], { type: mime });
  const f = new File([blob], file.originalname ?? "image.png", { type: mime });
  // undici File and globalThis File are structurally compatible at runtime;
  // cast through unknown to satisfy the fal SDK's DOM File type expectation.
  return await fal.storage.upload(f as unknown as globalThis.File);
}

export async function cleanupFiles(files: Express.Multer.File[]): Promise<void> {
  await Promise.all(files.map((f) => fs.unlink(f.path).catch(() => {})));
}

function normalizeFalImages(result: unknown): string[] {
  const data = (result as { data?: { images?: { url?: string }[] } })?.data ?? (result as { images?: { url?: string }[] }) ?? {};
  const images = (data as { images?: { url?: string }[] }).images ?? [];
  return images.map((img) => img.url ?? "").filter(Boolean);
}

export async function runFalNanoBananaEdit(opts: {
  anchorUrl: string;
  editUrl?: string;
  systemPrompt: string;
  prompt: string;
  numImages: number;
  aspectRatio: string;
  resolution: string;
}): Promise<string[]> {
  const image_urls = [opts.anchorUrl];
  if (opts.editUrl) image_urls.push(opts.editUrl);
  // Cast input to any: the fal SDK uses strict string literal unions for
  // aspect_ratio and resolution that match our allowed values at runtime,
  // but TypeScript can't narrow a runtime string to those union members.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const result = await fal.subscribe("fal-ai/nano-banana-2/edit", {
    input: {
      prompt: opts.prompt,
      system_prompt: opts.systemPrompt,
      image_urls,
      num_images: opts.numImages,
      aspect_ratio: opts.aspectRatio,
      resolution: opts.resolution,
      output_format: "png",
      safety_tolerance: "4",
    } as any,
    logs: true,
  });
  return normalizeFalImages(result);
}

export async function runFalPuLID(opts: {
  anchorUrl: string;
  systemPrompt: string;
  prompt: string;
  numImages: number;
}): Promise<string[]> {
  const mergedPrompt = `${opts.systemPrompt}\nScene request:\n${opts.prompt}`;
  // num_images is not in the fal SDK's FluxPulidInput type; the SDK controls
  // batch size internally. We drop it here rather than force an invalid cast.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const result = await fal.subscribe("fal-ai/flux-pulid", {
    input: {
      reference_image_url: opts.anchorUrl,
      prompt: mergedPrompt,
      id_weight: 1.35,
      num_inference_steps: 28,
      guidance_scale: 4.0,
      true_cfg: 1.0,
      output_format: "png",
    } as any,
    logs: true,
  });
  return normalizeFalImages(result);
}

export async function runFalFluxEdit(opts: {
  editUrl: string;
  systemPrompt: string;
  prompt: string;
  numImages: number;
  strength: number;
}): Promise<string[]> {
  const mergedPrompt = `${opts.systemPrompt}\nEdit request:\n${opts.prompt}`;
  const result = await fal.subscribe("fal-ai/flux-pro/v1.1-ultra", {
    input: {
      image_url: opts.editUrl,
      prompt: mergedPrompt,
      image_prompt_strength: opts.strength,
      num_images: opts.numImages,
      output_format: "png",
      safety_tolerance: "5",
    },
    logs: true,
  });
  return normalizeFalImages(result);
}

function aspectToSize(aspectRatio: string): { width: number; height: number } {
  if (aspectRatio === "4:5") return { width: 832, height: 1040 };
  if (aspectRatio === "3:4") return { width: 896, height: 1152 };
  if (aspectRatio === "2:3") return { width: 832, height: 1216 };
  if (aspectRatio === "16:9") return { width: 1216, height: 704 };
  return { width: 1024, height: 1024 };
}

function makeComfyWorkflow(prompt: string, aspectRatio: string): Record<string, unknown> {
  const { width, height } = aspectToSize(aspectRatio);
  const checkpoint = process.env.COMFY_CHECKPOINT ?? "photonicFusionSDXL_final.safetensors";
  const seed = Math.floor(Math.random() * 999_999_999_999);
  const negative = `worst quality, low quality, blurry, distorted face, wrong face, generic model face, skinny body, lean body, hairless body, smooth waxed body, fake blue eyes, plastic skin, airbrushed skin, cartoon, CGI, watermark, text`;
  return {
    "1": { class_type: "CheckpointLoaderSimple", inputs: { ckpt_name: checkpoint } },
    "2": { class_type: "CLIPTextEncode", inputs: { text: prompt, clip: ["1", 1] } },
    "3": { class_type: "CLIPTextEncode", inputs: { text: negative, clip: ["1", 1] } },
    "4": { class_type: "EmptyLatentImage", inputs: { width, height, batch_size: 1 } },
    "5": {
      class_type: "KSampler",
      inputs: {
        seed,
        steps: 24,
        cfg: 5.5,
        sampler_name: "euler",
        scheduler: "sgm_uniform",
        denoise: 1.0,
        model: ["1", 0],
        positive: ["2", 0],
        negative: ["3", 0],
        latent_image: ["4", 0],
      },
    },
    "6": { class_type: "VAEDecode", inputs: { samples: ["5", 0], vae: ["1", 2] } },
    "7": {
      class_type: "SaveImage",
      inputs: { filename_prefix: "KittyImageStudio", images: ["6", 0] },
    },
  };
}

async function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function runComfyRemoteBasic(opts: {
  prompt: string;
  aspectRatio: string;
}): Promise<string[]> {
  const comfyUrl = process.env.COMFY_URL;
  if (!comfyUrl) {
    throw new Error("COMFY_URL is not set. Add a RunPod/Colab/local ComfyUI URL first.");
  }
  const base = comfyUrl.replace(/\/$/, "");
  const workflow = makeComfyWorkflow(opts.prompt, opts.aspectRatio);
  const submit = await fetch(`${base}/prompt`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ prompt: workflow, client_id: "kitty-image-studio" }),
  });
  if (!submit.ok) throw new Error(`ComfyUI submit failed: ${submit.status}`);
  const submitData = (await submit.json()) as { prompt_id: string };
  const promptId = submitData.prompt_id;
  for (let i = 0; i < 80; i++) {
    await sleep(1500);
    const hist = await fetch(`${base}/history/${promptId}`);
    if (!hist.ok) continue;
    const history = (await hist.json()) as Record<
      string,
      { outputs?: Record<string, { images?: { filename: string; subfolder: string; type: string }[] }> }
    >;
    const item = history[promptId];
    if (!item?.outputs) continue;
    for (const nodeId of Object.keys(item.outputs)) {
      const output = item.outputs[nodeId];
      const img = output?.images?.[0];
      if (!img) continue;
      const params = new URLSearchParams({
        filename: img.filename,
        subfolder: img.subfolder ?? "",
        type: img.type ?? "output",
      });
      const view = await fetch(`${base}/view?${params.toString()}`);
      if (!view.ok) throw new Error(`ComfyUI image fetch failed: ${view.status}`);
      const buffer = Buffer.from(await view.arrayBuffer());
      return [`data:image/png;base64,${buffer.toString("base64")}`];
    }
  }
  throw new Error("ComfyUI timed out waiting for image.");
}
