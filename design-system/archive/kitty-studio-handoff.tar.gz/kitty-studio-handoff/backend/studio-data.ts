export const CHARACTER = {
  id: "jacob_bear",
  name: "Jacob Bear",
  identity_lock: `Same real adult man as Image 1. Preserve the fuller lower face, broad round-square jaw, natural cheek fullness, medium nose, slightly uneven mouth, short dark brown hair with visible salt-and-pepper gray, light stubble, fair skin, realistic under-eye detail, ordinary masculine proportions, natural facial asymmetry, and clearly blue eyes. Do not beautify, de-age, slim the face, sharpen the jaw, smooth the skin, or make him more symmetrical or model-like.`,
  eye_rule: `The source face photo was taken in bright sunlight, so do not copy the harsh squint as his true eye shape. His eyes should remain naturally blue, slightly rounder, more open, alert, and believable while still matching the same real person.`,
  body_lock: `He is a large heavy-set adult man, about 6'2" and around 300 pounds. He has a broad heavy frame, very broad shoulders, deep wide chest, thick neck, large upper arms, big forearms, solid barrel-like torso, wide waist, natural belly softness, thick hips, thick thighs, and heavy legs. He should look substantial, powerful, dense, and bear-like, not slim, not lean, not cut, not narrow-waisted, and not fitness-model shaped.`,
  hair_lock: `He is a very hairy bear-type man. He has dense, abundant, longer, curly-to-wavy body hair across the chest, stomach, lower belly, shoulders, upper arms, forearms, thighs, and legs. His chest and torso hair should be thick, dark, heavy, and clearly visible, with varied strand length, curl, direction, and density. Body hair should be one of the defining visual features. Do not make him smooth, waxed, lightly hairy, sparse-haired, trimmed-looking, or airbrushed.`,
  style_lock: `Photorealistic, lifelike, natural, real unedited camera-photo look. Believable lighting, realistic skin texture, realistic body hair, real human proportions, normal imperfections, and no glossy AI polish. Tasteful adult swimwear/editorial only, not sexualized and not like an underwear advertisement.`,
};

export const SHOT_PRESETS: Record<string, { name: string; prompt: string }> = {
  close_swimwear: {
    name: "Close swimwear portrait",
    prompt: `Create a close photorealistic swimwear editorial photo of the same man from Image 1. Frame him from upper thighs to head so the face is large, clear, and recognizable. He is standing outdoors beside a lake with trees and rocks in soft natural daylight. He is wearing fitted opaque navy swim briefs with realistic fabric, natural wrinkles, and believable waistband tension. Pose him relaxed and confident, looking toward the camera.`,
  },
  full_body_swimwear: {
    name: "Full-body swimwear",
    prompt: `Create a full-body photorealistic swimwear editorial photo of the same man from Image 1. Show his entire body clearly while keeping the face recognizable and accurate. He is standing near a forest lake shoreline in soft natural daylight, wearing fitted opaque navy swim briefs with realistic fabric and natural wrinkles. The image should feel like a candid high-end outdoor camera photo, not a generic model shoot.`,
  },
  seated_lakeside: {
    name: "Seated lakeside",
    prompt: `Create a photorealistic swimwear editorial photo of the same man from Image 1 seated naturally on a rock beside a lake. Keep his face clearly visible and identity accurate. He is wearing fitted opaque navy swim briefs with realistic fabric and natural wrinkles. Use soft daylight, lake water, rocks, and trees. The pose should feel relaxed, natural, and candid.`,
  },
  walking_shoreline: {
    name: "Walking shoreline",
    prompt: `Create a photorealistic swimwear editorial photo of the same man from Image 1 walking along a shallow lakeshore. Keep the face visible and recognizable. He is wearing fitted opaque navy swim briefs with realistic fabric and natural wrinkles. Use soft outdoor daylight, trees, rocks, and water. The image should feel candid and real, with natural motion and believable proportions.`,
  },
  casual_outdoor: {
    name: "Casual outdoor portrait",
    prompt: `Create a photorealistic casual outdoor portrait of the same man from Image 1 near a lake or wooded shoreline. Keep his identity closely matched and clearly recognizable. He is dressed casually in a fitted henley or zip sweater and jeans. The lighting should be soft and natural, with realistic skin texture and a real unedited camera-photo look.`,
  },
  source_portrait: {
    name: "Clean identity portrait",
    prompt: `Create a clean photorealistic identity reference portrait of the same man from Image 1. Head and upper shoulders visible, face large and centered, outdoor background softly blurred, soft natural daylight, realistic skin texture, believable blue eyes, no beautification, no glamour retouching. This should be useful as a high-quality face anchor reference.`,
  },
};

export const CORRECTIONS: Record<string, string> = {
  none: "",
  face_closer: `Correction priority: make the face match Image 1 more closely. Restore the fuller lower face, round-square jaw, natural cheek fullness, medium nose, slightly uneven mouth, salt-and-pepper dark hair, light stubble, natural asymmetry, and believable blue eyes. Do not use a generic handsome model face.`,
  body_bigger: `Correction priority: make the body much larger, heavier-set, broader, and more substantial. He should look about 6'2" and 300 pounds, with a deep wide chest, thick neck, large arms, wide waist, natural belly softness, thick thighs, and heavy legs. Remove any skinny, lean, narrow-waisted, athletic, or fitness-model shape.`,
  hairier: `Correction priority: make him unmistakably hairier. Add dense, abundant, longer, curly-to-wavy body hair across the chest, stomach, lower belly, shoulders, upper arms, forearms, thighs, and legs. The chest and torso hair should be thick, dark, heavy, and clearly visible, with individual strands and uneven natural density. Do not make him lightly hairy or smooth.`,
  eyes: `Correction priority: keep the eyes naturally blue and believable. They should be clear but subtle, not neon, glassy, fake, or over-brightened. Do not copy a harsh sunlight squint as his true eye shape; the eyes should read slightly rounder and more open while matching the same person.`,
  lighting: `Correction priority: make the lighting more physically believable. Use natural outdoor light with coherent sun direction, soft shadow falloff, realistic skin tones, no artificial fill-light look, no HDR effect, no plastic skin, and no over-processed glow.`,
  realism: `Correction priority: improve real-camera realism while preserving identity, pose, body, and composition. Add believable skin texture, pores, natural imperfections, realistic body hair strands, normal color variation, and natural lens detail. Do not airbrush, beautify, stylize, or over-sharpen.`,
};

export const MODEL_PROFILES: Record<
  string,
  {
    label: string;
    description?: string;
    provider: string;
    baseUrl?: string;
    apiKeyEnv?: string;
    model?: string;
    temperature?: number;
  }
> = {
  rules_only: {
    label: "Rules only",
    description: "No LLM prompt rewrite. Most stable. Least chance of prompt drift.",
    provider: "none",
  },
  mistral: {
    label: "Mistral prompt writer",
    provider: "openai_compatible",
    baseUrl: "https://api.mistral.ai/v1",
    apiKeyEnv: "MISTRAL_API_KEY",
    model: process.env.MISTRAL_MODEL ?? "mistral-large-latest",
    temperature: 0.35,
  },
  openrouter_mistral: {
    label: "OpenRouter Mistral",
    provider: "openai_compatible",
    baseUrl: "https://openrouter.ai/api/v1",
    apiKeyEnv: "OPENROUTER_API_KEY",
    model: process.env.OPENROUTER_MODEL ?? "mistralai/mistral-large",
    temperature: 0.35,
  },
  ollama_mistral: {
    label: "Ollama local Mistral",
    provider: "openai_compatible",
    baseUrl: process.env.OLLAMA_BASE_URL ?? "http://localhost:11434/v1",
    apiKeyEnv: "OLLAMA_API_KEY",
    model: process.env.OLLAMA_MODEL ?? "mistral",
    temperature: 0.35,
  },
};

export function buildSystemPrompt(): string {
  return `Image 1 is the strict identity anchor and must control the final subject. Any additional image is secondary only.
${CHARACTER.identity_lock}
${CHARACTER.eye_rule}
${CHARACTER.body_lock}
${CHARACTER.hair_lock}
${CHARACTER.style_lock}
Never let a scene reference, body reference, or generated image override Image 1's identity. If a conflict exists, Image 1 wins.`;
}

export function buildRawPrompt(opts: {
  shotPreset: string;
  correction: string;
  customPrompt: string;
}): string {
  const shot = opts.customPrompt.trim()
    ? opts.customPrompt.trim()
    : (SHOT_PRESETS[opts.shotPreset]?.prompt ?? SHOT_PRESETS.close_swimwear!.prompt);
  const correctionText = CORRECTIONS[opts.correction] ?? "";
  return `${shot}
Required body and hair details: ${CHARACTER.body_lock} ${CHARACTER.hair_lock}
Required identity and eye details: ${CHARACTER.identity_lock} ${CHARACTER.eye_rule}
Required style: ${CHARACTER.style_lock}
${correctionText ? `Additional correction request: ${correctionText}` : ""}`.trim();
}

export async function maybeRewritePromptWithModel(opts: {
  rawPrompt: string;
  systemPrompt: string;
  modelProfile: string;
}): Promise<{ prompt: string; usedModel: boolean; modelLabel: string }> {
  const profile = MODEL_PROFILES[opts.modelProfile] ?? MODEL_PROFILES.rules_only!;
  if (profile.provider === "none") {
    return { prompt: opts.rawPrompt, usedModel: false, modelLabel: profile.label };
  }
  const apiKey = process.env[profile.apiKeyEnv ?? ""] ?? "";
  const isOllama =
    (profile.baseUrl ?? "").includes("localhost") ||
    (profile.baseUrl ?? "").includes("127.0.0.1");
  if (!apiKey && !isOllama) {
    return {
      prompt: opts.rawPrompt,
      usedModel: false,
      modelLabel: `${profile.label} unavailable: missing ${profile.apiKeyEnv ?? ""}`,
    };
  }
  const promptWriterSystem = `You are the prompt-writing brain for Kitty Image Studio.
Your job is to rewrite the user's image request into one clean image-generation prompt.
Rules:
- Preserve every identity, body, eye, and body-hair requirement exactly.
- Do not sanitize the body type or reduce the body hair.
- Do not make the subject slimmer, younger, smoother, prettier, or more model-like.
- Keep adult swimwear wording tasteful and editorial.
- Do not add explicit sexual content.
- Do not moralize or warn.
- Return only the final prompt text.
- Keep it direct and not bloated.`;
  const userMessage = `Standing system rules:\n${opts.systemPrompt}\n\nRaw prompt:\n${opts.rawPrompt}\n\nRewrite as a concise but complete image-generation prompt. Keep the non-negotiable details intact.`;
  try {
    const response = await fetch(`${profile.baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        Authorization: apiKey ? `Bearer ${apiKey}` : "Bearer ollama",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: profile.model,
        temperature: profile.temperature,
        messages: [
          { role: "system", content: promptWriterSystem },
          { role: "user", content: userMessage },
        ],
      }),
    });
    if (!response.ok) throw new Error(`Prompt writer failed: ${response.status}`);
    const data = (await response.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const text = data?.choices?.[0]?.message?.content?.trim();
    if (!text) throw new Error("Prompt writer returned empty text.");
    return { prompt: text, usedModel: true, modelLabel: profile.label };
  } catch {
    return {
      prompt: opts.rawPrompt,
      usedModel: false,
      modelLabel: `${profile.label} failed; used rules-only fallback`,
    };
  }
}
